package Project2;

import java.util.Scanner;

public class sleepandwait {
    private static Object LOCK = new Object();

    public static void main(String args[]) throws InterruptedException {
        // Taking user input for sleep duration in seconds
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter sleep duration in seconds: ");
        int sleepDurationInSeconds = scanner.nextInt();

        // Convert sleep duration to milliseconds
        long sleepDuration = sleepDurationInSeconds * 1000;

        // Using Thread.sleep with user input
        System.out.println("Thread '" + Thread.currentThread().getName() + "' is going to sleep for " + sleepDurationInSeconds + " seconds");
        Thread.sleep(sleepDuration);
        System.out.println("Thread '" + Thread.currentThread().getName() + "' is woken after sleeping for " + sleepDurationInSeconds + " seconds");

        // Taking user input for wait duration in seconds
        System.out.print("Enter wait duration in seconds: ");
        int waitDurationInSeconds = scanner.nextInt();

        // Convert wait duration to milliseconds
        long waitDuration = waitDurationInSeconds * 1000;

        // Using Object.wait with user input
        synchronized (LOCK) {
            System.out.println("Object '" + LOCK + "' is going to wait for " + waitDurationInSeconds + " seconds");
            LOCK.wait(waitDuration);
            System.out.println("Object '" + LOCK + "' is woken after waiting for " + waitDurationInSeconds + " seconds");
        }

        // Close the scanner
        scanner.close();
    }
}