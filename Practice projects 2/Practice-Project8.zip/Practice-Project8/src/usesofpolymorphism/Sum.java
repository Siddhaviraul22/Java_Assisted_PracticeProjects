package usesofpolymorphism;

import java.util.Scanner;

	public class Sum {
	    public int sum(int x, int y) {
	        return x + y;
	    }

	    public int sum(int x, int y, int z) {
	        return x + y + z;
	    }

	    public double sum(double x, double y) {
	        return x + y;
	    }

	    public static void main(String args[]) {
	        Scanner scanner = new Scanner(System.in);
	        Sum s = new Sum();

	        System.out.println("Enter two integers for the first sum:");
	        int int1 = scanner.nextInt();
	        int int2 = scanner.nextInt();
	        System.out.println("Result: " + s.sum(int1, int2));

	        System.out.println("Enter three integers for the second sum:");
	        int int3 = scanner.nextInt();
	        int int4 = scanner.nextInt();
	        int int5 = scanner.nextInt();
	        System.out.println("Result: " + s.sum(int3, int4, int5));

	        System.out.println("Enter two doubles for the third sum:");
	        double double1 = scanner.nextDouble();
	        double double2 = scanner.nextDouble();
	        System.out.println("Result: " + s.sum(double1, double2));

	        scanner.close();
	    }
	}
