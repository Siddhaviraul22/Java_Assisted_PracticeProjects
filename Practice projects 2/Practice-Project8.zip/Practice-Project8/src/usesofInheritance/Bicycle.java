package usesofInheritance;

public class Bicycle {
    // Instance variables
    private int gear;
    private int speed;

    // Constructor
    public Bicycle(int gear, int speed) {
        this.gear = gear;
        this.speed = speed;
    }

    // Method to apply brakes
    public void applyBrake(int decrement) {
        speed -= decrement;
    }

    // Method to speed up
    public void speedUp(int increment) {
        speed += increment;
    }

    // Method to get current gear
    public int getGear() {
        return gear;
    }

    // Method to get current speed
    public int getSpeed() {
        return speed;
    }

    // Method to display bicycle information
    @Override
    public String toString() {
        return "Bicycle [gear=" + gear + ", speed=" + speed + "]";
    }
}