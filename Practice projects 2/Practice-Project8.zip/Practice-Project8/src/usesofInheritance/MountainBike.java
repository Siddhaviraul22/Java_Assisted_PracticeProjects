package usesofInheritance;

public class MountainBike extends Bicycle {
    // Additional instance variable for MountainBike
    private int seatHeight;

    // Constructor for MountainBike
    public MountainBike(int gear, int speed, int startHeight) {
        // Call the constructor of the superclass (Bicycle)
        super(gear, speed);
        // Initialize the additional variable
        seatHeight = startHeight;
    }

    // Method to set the seat height
    public void setSeatHeight(int newValue) {
        seatHeight = newValue;
    }

    // Method to get the seat height
    public int getSeatHeight() {
        return seatHeight;
    }

    // Override the toString method to include seat height
    @Override
    public String toString() {
        return super.toString() + ", seat height=" + seatHeight;
    }
}