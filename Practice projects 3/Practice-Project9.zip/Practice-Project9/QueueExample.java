package Project9;

import java.util.LinkedList;
import java.util.Queue;

public class QueueExample 
{
    public static void main(String[] args) 
    {
        Queue<String> locationsQueue = new LinkedList<>();

        // Adding elements to the queue
        locationsQueue.add("Kolkata");
        locationsQueue.add("Patna");
        locationsQueue.add("Delhi");
        locationsQueue.add("Gurgaon");
        locationsQueue.add("Noida");

        // Printing the initial state of the queue
        System.out.println("Queue is : " + locationsQueue);

        // Printing the head of the queue without removing it
        System.out.println("Head of Queue : " + locationsQueue.peek());

        // Removing the head of the queue
        locationsQueue.remove();

        // Printing the state of the queue after removing the head
        System.out.println("After removing Head of Queue : " + locationsQueue);

        // Printing the size of the queue
        System.out.println("Size of Queue : " + locationsQueue.size());
    }
}