package TypeCasting;

import java.util.Scanner;

public class Implicit_and_explicit {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Implicit conversion
        System.out.println("Implicit Type Casting");

        System.out.print("Enter a character (char): ");
        char charValue = scanner.next().charAt(0);
        System.out.println("Value of charValue: " + charValue);

        int intValueFromChar = charValue;
        System.out.println("Value of intValueFromChar: " + intValueFromChar);

        float floatValueFromChar = charValue;
        System.out.println("Value of floatValueFromChar: " + floatValueFromChar);

        long longValueFromChar = charValue;
        System.out.println("Value of longValueFromChar: " + longValueFromChar);

        double doubleValueFromChar = charValue;
        System.out.println("Value of doubleValueFromChar: " + doubleValueFromChar);

        System.out.println("\nExplicit Type Casting");

        // Explicit conversion
        System.out.print("Enter a double value (doubleValue): ");
        double doubleValue = scanner.nextDouble();
        int intValueFromDouble = (int) doubleValue;

        System.out.println("Value of doubleValue: " + doubleValue);
        System.out.println("Value of intValueFromDouble: " + intValueFromDouble);

        // Close the scanner
        scanner.close();
    }
}