package project7;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;
import java.util.List;

public class CreateNewFile {
    public static void main(String[] args) {
        try {
            createFileUsingFileClass();
            createFileUsingFileOutputStreamClass();
            createFileInNIO();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void createFileUsingFileClass() throws IOException {
        File file = new File("C:\\\\Users\\\\DELL\\\\Desktop\\\\Main\\\\testFile2.txt");

        if (file.createNewFile()) {
            System.out.println("File is created!");
        } else {
            System.out.println("File already exists.");
        }

        try (FileWriter writer = new FileWriter(file)) {
            writer.write("Test data");
        }
    }

    private static void createFileUsingFileOutputStreamClass() throws IOException {
        String data = "Test data";
        try (FileOutputStream out = new FileOutputStream("C:\\Users\\DELL\\Desktop\\Main\\testFile2.txt")) {
            out.write(data.getBytes());
        }
    }

    private static void createFileInNIO() throws IOException {
        String data = "Test data";
        Files.write(Paths.get("C:\\\\Users\\\\DELL\\\\Desktop\\\\Main\\\\testFile2.txt"), data.getBytes());

        List<String> lines = Arrays.asList("1st line", "2nd line");
        Files.write(Paths.get("file6.txt"),
                lines,
                StandardCharsets.UTF_8,
                StandardOpenOption.CREATE,
                StandardOpenOption.APPEND);
    }
}
