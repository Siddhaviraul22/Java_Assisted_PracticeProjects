package Defaultconstructor;
import java.util.Scanner;
public class constructorDemo {
	 public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        empInfo emp1 = new empInfo();
	        empInfo emp2 = new empInfo();

	        emp1.takeInput(scanner, "Enter details for Employee 1:");
	        emp2.takeInput(scanner, "Enter details for Employee 2:");

	        emp1.display();
	        emp2.display();

	        scanner.close();
	    }
	}

