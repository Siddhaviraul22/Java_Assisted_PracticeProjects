package Defaultconstructor;
import java.util.Scanner;
public class empInfo {
	int id;
    String name;

    void display() {
        System.out.println(id + " " + name);
    }

    void takeInput(Scanner scanner, String prompt) {
        System.out.println(prompt);
        System.out.print("Enter ID: ");
        id = scanner.nextInt();
        System.out.print("Enter Name: ");
        name = scanner.next();
    }
}
