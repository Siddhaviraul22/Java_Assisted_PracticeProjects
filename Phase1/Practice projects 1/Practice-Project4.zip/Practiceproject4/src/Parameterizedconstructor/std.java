package Parameterizedconstructor;
import java.util.Scanner;

public class std {
    int id;
    String name;

    std(int i, String n) {
        id = i;
        name = n;
    }

    void display() {
        System.out.println(id + " " + name);
    }

    static std takeInput(Scanner scanner, String prompt) {
        System.out.println(prompt);
        System.out.print("Enter ID: ");
        int id = scanner.nextInt();
        System.out.print("Enter Name: ");
        String name = scanner.next();
        return new std(id, name);
    }
}
