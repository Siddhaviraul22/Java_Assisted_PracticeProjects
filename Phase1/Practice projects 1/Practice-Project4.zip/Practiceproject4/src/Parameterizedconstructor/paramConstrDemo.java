package Parameterizedconstructor;
import java.util.Scanner;
public class paramConstrDemo {
	 public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        std std1 = std.takeInput(scanner, "Enter details for Student 1:");
	        std std2 = std.takeInput(scanner, "Enter details for Student 2:");

	        std1.display();
	        std2.display();

	        scanner.close();
	    }
	}
