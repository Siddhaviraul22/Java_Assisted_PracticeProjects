package collections;
import java.util.*;
public class collectionAssisted {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Creating ArrayList
        System.out.println("ArrayList");
        ArrayList<String> city = new ArrayList<>();
        System.out.println("Enter cities (type 'done' when finished): ");
        String cityInput;
        while (!(cityInput = scanner.nextLine()).equalsIgnoreCase("done")) {
            city.add(cityInput);
        }
        System.out.println("Cities: " + city);

        // Creating Vector
        System.out.println("\nVector");
        Vector<Integer> vec = new Vector<>();
        System.out.println("Enter integers (type '0' when finished): ");
        int vecInput;
        while ((vecInput = scanner.nextInt()) != 0) {
            vec.addElement(vecInput);
        }
        System.out.println("Vector elements: " + vec);

        // Creating LinkedList
        System.out.println("\nLinkedList");
        LinkedList<String> names = new LinkedList<>();
        System.out.println("Enter names (type 'done' when finished): ");
        scanner.nextLine(); // Consume the newline character left by nextInt
        String nameInput;
        while (!(nameInput = scanner.nextLine()).equalsIgnoreCase("done")) {
            names.add(nameInput);
        }
        System.out.println("Names: " + names);

        // Creating HashSet
        System.out.println("\nHashSet");
        HashSet<Integer> set = new HashSet<>();
        System.out.println("Enter integers (type '0' when finished): ");
        int setInput;
        while ((setInput = scanner.nextInt()) != 0) {
            set.add(setInput);
        }
        System.out.println("HashSet elements: " + set);

        // Creating LinkedHashSet
        System.out.println("\nLinkedHashSet");
        LinkedHashSet<Integer> set2 = new LinkedHashSet<>();
        System.out.println("Enter integers (type '0' when finished): ");
        int set2Input;
        while ((set2Input = scanner.nextInt()) != 0) {
            set2.add(set2Input);
        }
        System.out.println("LinkedHashSet elements: " + set2);

        // Close the scanner to avoid resource leak
        scanner.close();
    }

}
