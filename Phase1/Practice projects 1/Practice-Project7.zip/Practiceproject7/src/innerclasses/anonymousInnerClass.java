package innerclasses;

interface anonymousInnerClass {
	   void msg();

	void display();
	}
