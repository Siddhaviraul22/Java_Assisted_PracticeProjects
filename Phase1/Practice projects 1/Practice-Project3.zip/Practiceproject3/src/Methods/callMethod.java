package Methods;
import java.util.Scanner;
public class callMethod {

	int val;

    void operation(int val) {
        this.val = val * 10 / 100;  // Assign the result to the instance variable 'val'
    }

    public static void main(String args[]) {
        Scanner scanner = new Scanner(System.in);

        callMethod d = new callMethod();

        System.out.print("Enter a value for the operation: ");
        int inputValue = scanner.nextInt();

        d.operation(inputValue);
        System.out.println("After operation value of data is " + d.val);

        scanner.close();
    }
}
