package Methods;
import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Example 1: methodExecution
        methodExecutionExample(scanner);

        // Example 2: callMethod
        callMethodExample(scanner);

        // Example 3: overloadMethod
        overloadMethodExample(scanner);

        scanner.close();
    }

    private static void methodExecutionExample(Scanner scanner) {
        System.out.println("Example 1: methodExecution");
        System.out.print("Enter the first number: ");
        int num1 = scanner.nextInt();
        System.out.print("Enter the second number: ");
        int num2 = scanner.nextInt();

        methodExecution b = new methodExecution();
        int ans = b.multiplyNumbers(num1, num2);
        System.out.println("Multiplication is: " + ans);
        System.out.println();
    }

    private static void callMethodExample(Scanner scanner) {
        System.out.println("Example 2: callMethod");
        callMethod d = new callMethod();

        System.out.print("Enter a value for the operation: ");
        int inputValue = scanner.nextInt();

        d.operation(inputValue);
        System.out.println("After operation value of data is " + d.val);
        System.out.println();
    }

    private static void overloadMethodExample(Scanner scanner) {
        System.out.println("Example 3: overloadMethod");
        overloadMethod ob = new overloadMethod();

        System.out.print("Enter base length for the triangle: ");
        int base = scanner.nextInt();
        System.out.print("Enter height for the triangle: ");
        int height = scanner.nextInt();
        ob.area(base, height);

        System.out.print("Enter the radius for the circle: ");
        int radius = scanner.nextInt();
        ob.area(radius);
        System.out.println();
    }
}
