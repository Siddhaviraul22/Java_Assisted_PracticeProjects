package Methods;

public class methodExecution {
	public int multiplyNumbers(int a, int b) {
        int z = a * b;
        return z;
    }
}
