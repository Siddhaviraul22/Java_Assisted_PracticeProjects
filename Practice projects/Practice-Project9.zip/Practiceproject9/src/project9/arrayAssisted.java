package project9;
import java.util.Scanner;

public class arrayAssisted {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Single-dimensional array
        int[] a = new int[5];
        System.out.println("Enter elements for array a:");

        for (int i = 0; i < 5; i++) {
            System.out.print("Enter element " + (i + 1) + ": ");
            a[i] = scanner.nextInt();
        }

        System.out.println("Elements of array a:");
        for (int i = 0; i < 5; i++) {
            System.out.println(a[i]);
        }

        // Multidimensional array
        System.out.println("\nEnter the number of rows for array b:");
        int rows = scanner.nextInt();
        System.out.println("Enter the number of columns for array b:");
        int cols = scanner.nextInt();

        int[][] b = new int[rows][cols];

        System.out.println("Enter elements for array b:");

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.print("Enter element at position (" + (i + 1) + "," + (j + 1) + "): ");
                b[i][j] = scanner.nextInt();
            }
        }

        System.out.println("\nElements of array b:");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.print(b[i][j] + " ");
            }
            System.out.println();
        }

        // Close the scanner to prevent resource leak
        scanner.close();
    }
}