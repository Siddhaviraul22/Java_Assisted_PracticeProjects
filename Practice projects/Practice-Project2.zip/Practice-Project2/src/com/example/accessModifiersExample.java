package com.example;

public class accessModifiersExample {
    // Public field accessible from anywhere
    public int publicField = 1;
    
    // Protected field accessible within the same package and subclasses
    protected int protectedField = 2;
    
    // Default (package-private) field accessible only within the same package
    int defaultField = 3;
    
    // Private field accessible only within the same class
    private int privateField = 4;

    // Public method accessible from anywhere
    public void publicMethod() {
        System.out.println("Public method called");
    }

    // Protected method accessible within the same package and subclasses
    protected void protectedMethod() {
        System.out.println("Protected method called");
    }

    // Default (package-private) method accessible only within the same package
    void defaultMethod() {
        System.out.println("Default method called");
    }

    // Private method accessible only within the same class
    private void privateMethod() {
        System.out.println("Private method called");
    }
    
    // Main method to demonstrate access modifiers
    public static void main(String[] args) {
        accessModifiersExample example = new accessModifiersExample();
        
        // Accessing fields and methods
        System.out.println("Public field value: " + example.publicField);
        System.out.println("Protected field value: " + example.protectedField);
        System.out.println("Default field value: " + example.defaultField);
        System.out.println("Private field value: " + example.privateField);

        example.publicMethod();
        example.protectedMethod();
        example.defaultMethod();
        example.privateMethod();
    }
}
